import React from "react";

const Credits = () => {
    return <div></div>;
};

export default Credits;

import { React, useState } from "react";

import HeaderButtons from "./GameBoard/HeaderButtons";
import BoardView from "./GameBoard/BoardView";
import GameMessage from "./GameBoard/GameMessage";
import ClueInput from "./GameBoard/ClueInput";
import FooterButtons from "./GameBoard/FooterButtons";
import RulesPopUp from "./GameBoard/RulesPopUp";

const GameBoard = () => {
    const [showRules, setShowRules] = useState(false);

    const toggleRules = () => {
        setShowRules(!showRules);
    };

    return (
        <div className="flex flex-col -mt-8 lg:mt-0 mx-auto w-full sm:w-4/5 lg:w-3/5 xl:w-2/5">
            <HeaderButtons toggleRules={toggleRules} />

            {showRules && <RulesPopUp closeRules={toggleRules} />}

            <BoardView />

            <GameMessage />

            <ClueInput />

            <FooterButtons />
        </div>
    );
};

export default GameBoard;

// gameHistory button: book

// shuffleWords button: interlaced arrows

// changeView button: table or grid depending on ViewContext
// define abstract BoardView class, two concrete classes TableView and GridView
// GridView: composed of Cards
// TableView: composed of TableSections
